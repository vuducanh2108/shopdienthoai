<?php

namespace App\Repositories;

use App\Repositories\Search\Conditions;

interface RepositoryInterface
{
    public function saveData($data);

    public function create();

    public function find($id);

    public function getCollectionData(Conditions $conditions);

    public function getDataBy(Conditions $conditions);


}
