<?php


namespace App\Repositories;

use App\Repositories\Search\Conditions;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class BaseRepository implements RepositoryInterface
{
    protected $model;

    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    public function delete($ids)
    {
        if (is_array($ids)) {
            foreach ($ids as $id) {
                $this->find($id)->delete();
            }
            return true;
        }
        return $this->find($ids)->delete();
    }

    public function create()
    {
        return $this->model;
    }

    public function find($id)
    {
        return $this->create()->find($id);
    }


    public function saveData($data)
    {
        $model = $this->model;
        if (isset($data['id'])) {
            $model = $this->model->findOrFail($data['id']);
        }
        return $model->fill($data)->save();
    }

    public function getCollectionData($conditions = null)
    {
        $model = $this->create();
        if ($conditions instanceof Conditions) {
            $model = $this->applyFilterGroup($conditions, $model);
            $model = $this->applyWithCount($conditions, $model);
            $model = $this->applyWith($conditions, $model);
            $model = $this->applyLoadWithRelationships($conditions, $model);
        }

        return $model;
    }

    /**
     * @param Conditions $conditions
     * @return mixed
     */
    public function getDataBy(Conditions $conditions)
    {
        $model = $this->getCollectionData($conditions);

        if ($conditions instanceof Conditions) {

            if ($conditions->getOrderBy()) {
                foreach ($conditions->getOrderBy() as $orderBy) {
                    $model = $model->orderBy($orderBy->getField(), $orderBy->getDirection());
                }
            }
            //pagination
            if ($conditions->getCurrentPage()) {
                if (!$conditions->getPageSize()) {
                    $conditions->setPageSize(10);
                }
                $currentPage = $conditions->getCurrentPage();
                // Set current page
                Paginator::currentPageResolver(function () use ($currentPage) {
                    return $currentPage;
                });


                $list = $model
                    ->paginate($conditions->getPageSize());
                if ($list->lastPage() < $list->currentPage()) {
                    $currentPage = $list->lastPage();
                    // Set current page
                    Paginator::currentPageResolver(function () use ($currentPage) {
                        return $currentPage;
                    });
                    $list = $model
                        ->paginate($conditions->getPageSize());
                }
                return $list;
            }
        }

        return $model->get();
    }

    private function applyFilterGroup(Conditions $conditions, $model)
    {
        if ($conditions->getFilterGroups()) {
            foreach ($conditions->getFilterGroups() as $filterGroups) {
                $model = $model->where(function ($q) use ($filterGroups) {
                    foreach ($filterGroups->getFilter() as $filter) {
                        $condition_type = strtolower($filter->getConditionType());
                        switch ($condition_type) {
                            case 'in':
                                $q->orWhereIn($filter->getField(), $filter->getValue());
                                break;
                            case 'between':
                                $q->orWhereBetween($filter->getField(), $filter->getValue());
                                break;
                            case 'not_between':
                                $q->orWhereNotBetween($filter->getField(), $filter->getValue());
                                break;
                            default:
                                $q->orWhere($filter->getField(),
                                    $condition_type,
                                    $filter->getValue());
                        }
                    }
                });
            }
        }
        return $model;
    }

    private function applyWithCount(Conditions $conditions, $model)
    {
        if ($conditions->getWithCount()) {
            foreach ($conditions->getWithCount() as $withCount) {
                $model->withCount($withCount);
            }
        }
        return $model;
    }

    private function applyWith(Conditions $conditions, $model)
    {
        if ($conditions->getWith()) {
            foreach ($conditions->getWith() as $with => $filterGroups) {
                foreach ($filterGroups as $filterWith) {
                    $model = $model->wherehas($with, function ($q) use ($filterWith) {
                        foreach ($filterWith->getFilter() as $k => $filter) {
                            if ($k == 0) {
                                $q->where($filter->getField(),
                                    $filter->getConditionType(),
                                    $filter->getValue());
                            } else {
                                $q->orWHere($filter->getField(),
                                    $filter->getConditionType(),
                                    $filter->getValue());
                            }
                        }
                    });
                }
            }
        }
        return $model;
    }

    private function applyLoadWithRelationships(Conditions $conditions, $model)
    {
        if ($conditions->getLoad()) {
            foreach ($conditions->getLoad() as $load) {
                $model = $model->with($load);
            }
        }
        return $model;
    }

}
